import React from 'react'
import "./Responsive_table.css"
import { MdVerified  } from 'react-icons/md'
import cook1 from "../Accets/cook1.avif"
import cook2 from "../Accets/cook2.webp"
import cook3 from "../Accets/cook3.avif"
import cook4 from "../Accets/cook4.webp"
import cook5 from "../Accets/cook5.avif"
import cook6 from "../Accets/cook6.webp"
import cook7 from "../Accets/cook7.avif"
import cook8 from "../Accets/cook8.avif"
import cook9 from "../Accets/cooks9.avif"
import cook10 from "../Accets/cool10.webp"
function Responsive_table() {
  return (
    <div>
      <div className=" pe-3 ps-1 m-0  d-block d-md-none">
      <div className="row justify-content-center align-items-center p-0">
                    <div className="col-4">
                      <div className="coloction pt-4">
                        <p>collocetion</p>
                      </div>
                        <div className='d-flex  align-items-center'>
<h3 className=' pe-2  tet-res'>1</h3>
<span className='img-respos'><img src={cook1} alt="" /></span>

    </div>
                    </div>
                    <div className="col-5 d-flex  macho  mt-5 px-0">
                        <div className=''>
                    <div className='text-start  fw-bold d-flex mager-text m-0'><p className='mb-0'>RTFKT- MNLTH X</p><MdVerified className='icons-res'/>    </div>
                    <div className='floor-res d-flex p-0 '><span className=''>FLOOR:</span>
                    <p className='fw-bold '>0.50 ETH</p></div>
                    </div>

                    </div>
                   
                    <div className="col-3 res-postion">
                    <div className='floor text-start pt-1 pb-3'><p>VOLUME</p></div>
                        <div className="">
                          <p className='fw-bold text180 pt-2'>180 ETH</p>
                        </div>
                    </div>
                </div>
  {/* second card  */}
                <div className="row justify-content-center align-items-center pt-3">
                    <div className="col-4">
                      {/* <div className="coloction">
                        <p>collocetion</p>
                      </div> */}
                        <div className='d-flex  align-items-center'>
<h3 className=' pe-2  tet-res'>2</h3>
<span className='img-respos'><img src={cook2} alt="" /></span>

    </div>
                    </div>
                    <div className="col-5 d-flex  macho mt-1  px-0">
                        <div className=''>
                    <div className='text-start  fw-bold d-flex mager-text m-0'><p className='mb-0'>RTFKT- MNLTH X</p><MdVerified className='icons-res'/>    </div>
                    <div className='floor-res d-flex p-0 '><span className=''>FLOOR:</span>
                    <p className='fw-bold '>0.50 ETH</p></div>
                    </div>

                    </div>
                   
                    <div className="col-3 res-postion">
                    {/* <div className='floor text-start'><p>VOLUME</p></div> */}
                        <div className="">
                          <p className='fw-bold text180 pt-3'>180 ETH</p>
                        </div>
                    </div>
                </div>
{/* 3rd card  */}
 
<div className="row justify-content-center align-items-center pt-3">
                    <div className="col-4">
                      {/* <div className="coloction">
                        <p>collocetion</p>
                      </div> */}
                        <div className='d-flex  align-items-center'>
<h3 className=' pe-2  tet-res'>3</h3>
<span className='img-respos'><img src={cook3} alt="" /></span>

    </div>
                    </div>
                    <div className="col-5 d-flex  macho mt-1  px-0">
                        <div className=''>
                    <div className='text-start  fw-bold d-flex mager-text m-0'><p className='mb-0'>RTFKT- MNLTH X</p><MdVerified className='icons-res'/>    </div>
                    <div className='floor-res d-flex p-0 '><span className=''>FLOOR:</span>
                    <p className='fw-bold '>0.50 ETH</p></div>
                    </div>

                    </div>
                   
                    <div className="col-3 res-postion">
                    {/* <div className='floor text-start'><p>VOLUME</p></div> */}
                        <div className="">
                          <p className='fw-bold text180 pt-3'>180 ETH</p>
                        </div>
                    </div>
                </div>
{/* 4th card  */}
<div className="row justify-content-center align-items-center pt-3">
                    <div className="col-4">
                      {/* <div className="coloction">
                        <p>collocetion</p>
                      </div> */}
                        <div className='d-flex  align-items-center'>
<h3 className=' pe-2  tet-res'>4</h3>
<span className='img-respos'><img src={cook4} alt="" /></span>

    </div>
                    </div>
                    <div className="col-5 d-flex  macho mt-1  px-0">
                        <div className=''>
                    <div className='text-start  fw-bold d-flex mager-text m-0'><p className='mb-0'>RTFKT- MNLTH X</p><MdVerified className='icons-res'/>    </div>
                    <div className='floor-res d-flex p-0 '><span className=''>FLOOR:</span>
                    <p className='fw-bold '>0.50 ETH</p></div>
                    </div>

                    </div>
                   
                    <div className="col-3 res-postion">
                    {/* <div className='floor text-start'><p>VOLUME</p></div> */}
                        <div className="">
                          <p className='fw-bold text180 pt-3'>180 ETH</p>
                        </div>
                    </div>
                </div>
{/* 5th card  */}
<div className="row justify-content-center align-items-center pt-3">
                    <div className="col-4">
                      {/* <div className="coloction">
                        <p>collocetion</p>
                      </div> */}
                        <div className='d-flex  align-items-center'>
<h3 className=' pe-2  tet-res'>5</h3>
<span className='img-respos'><img src={cook5} alt="" /></span>

    </div>
                    </div>
                    <div className="col-5 d-flex  macho mt-1  px-0">
                        <div className=''>
                    <div className='text-start  fw-bold d-flex mager-text m-0'><p className='mb-0'>RTFKT- MNLTH X</p><MdVerified className='icons-res'/>    </div>
                    <div className='floor-res d-flex p-0 '><span className=''>FLOOR:</span>
                    <p className='fw-bold '>0.50 ETH</p></div>
                    </div>

                    </div>
                   
                    <div className="col-3 res-postion">
                    {/* <div className='floor text-start'><p>VOLUME</p></div> */}
                        <div className="">
                          <p className='fw-bold text180 pt-3'>180 ETH</p>
                        </div>
                    </div>
                </div>

      </div>
      

    </div>
  )
}

export default Responsive_table
