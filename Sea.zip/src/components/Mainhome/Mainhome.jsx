import React from 'react'
import Frist_open from "../Frist_open/Frist_open"
import Ecsnft from "../first_slider/Ecsnft"
import Simple_two_cards from "../Simple_two_cards/Simple_two_cards"
import Responsive from '../Responsive/Responsive'
function Mainhome() {
  return (
    <div>
   
      <Frist_open/>
      <Responsive/>
      <Ecsnft/>
      <Simple_two_cards/>
    </div>
  )
}

export default Mainhome
