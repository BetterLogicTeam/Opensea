import React from 'react'
import Responsive_table from '../Responsive_table/Responsive_table'
import Table_col from '../Table_col/Table_col'
import Icon_bar from '../Icon_bar/Icon_bar'
import Icon_and_tab from '../Icon_and_tab/Icon_and_tab'

function Responsive() {
  return (
    <div>
      <Icon_and_tab/>
      
    
    </div>
  )
}

export default Responsive
