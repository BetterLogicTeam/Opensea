import React from 'react'
import "./Icon_and_tab.css"
import Icon_bar from '../Icon_bar/Icon_bar'
import Icon_bar_respon from '../Icon_bar_respon/Icon_bar_respon'
import Tab from '../Tab/Tab'
function Icon_and_tab() {
    return (
        <div>
            <div className="container-fluid dowm">
                <div className="row p-0">
                   
                        <Tab />
                   
                    
                </div>
            </div>
        </div>
    )
}

export default Icon_and_tab
